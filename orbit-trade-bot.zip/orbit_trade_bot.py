import requests
import pandas as pd
import ta
import os
from telegram.ext import Updater, MessageHandler, Filters

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

def analyze_chart(symbol="BTCUSDT", timeframe="15", limit=100):
    url = f"https://api.delta.exchange/v2/candles?market_name={symbol}&resolution={timeframe}&limit={limit}"
    response = requests.get(url)
    if response.status_code != 200:
        return None, None

    candles = response.json().get("result", [])
    if not candles:
        return None, None

    df = pd.DataFrame(candles)
    df.columns = ['time', 'open', 'high', 'low', 'close', 'volume']
    df = df.astype(float)
    df['rsi'] = ta.momentum.RSIIndicator(close=df['close']).rsi()

    latest_price = df['close'].iloc[-1]
    latest_rsi = df['rsi'].iloc[-1]

    if latest_rsi > 70:
        signal = "SHORT (Overbought)"
    elif latest_rsi < 30:
        signal = "LONG (Oversold)"
    else:
        signal = "WAIT (Neutral)"

    return signal, latest_price

def send_trade(update, context):
    signal, price = analyze_chart()
    if signal:
        msg = f"""
📊 *Delta Signal — Live*
Asset: BTC  
TF: 15m  
Price: ${price:.2f}  
Signal: {signal}  
🎯 Entry: {round(price, 2)}  
❌ SL: {round(price + 300, 2) if 'SHORT' in signal else round(price - 300, 2)}  
✅ TP1: {round(price - 600, 2) if 'SHORT' in signal else round(price + 600, 2)}  
✅ TP2: {round(price - 1200, 2) if 'SHORT' in signal else round(price + 1200, 2)}  
🕒 Valid for next 30–45 min
"""
        context.bot.send_message(chat_id=CHAT_ID, text=msg, parse_mode="Markdown")

def main():
    updater = Updater(BOT_TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, send_trade))
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()